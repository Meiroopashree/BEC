export const apiUrl = 'https://8080-abfdabeabcbaedbfedabcebcbbdccdcbecea.premiumproject.examly.io';
