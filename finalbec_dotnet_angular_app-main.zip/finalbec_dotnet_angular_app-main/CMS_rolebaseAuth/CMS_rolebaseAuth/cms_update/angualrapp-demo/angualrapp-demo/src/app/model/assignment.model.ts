export interface Assignment {
    ContainerId: number;
    UserId: number;
    Status: string;
    Route: string;
    Shipment: string;
    Destination: string;
}