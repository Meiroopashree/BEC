import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-assignment',
  templateUrl: './view-assignment.component.html',
  styleUrls: ['./view-assignment.component.css']
})
export class ViewAssignmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
