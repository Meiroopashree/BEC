export interface User {
    UserId?: number;
    Email: string;
    Username: string;
    Password: string;
    MobileNumber: string;
    UserRole: string;
  }
