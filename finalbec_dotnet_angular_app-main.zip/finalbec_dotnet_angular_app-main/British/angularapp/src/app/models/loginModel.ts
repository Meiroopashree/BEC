export interface LoginModel {
    Email: string;
    Password: string;
  }
